import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  menuIndex = 1;
  constructor() {
  }
  menuClick(index) {
    this.menuIndex = index;
  }
  ngOnInit() {
  }
}