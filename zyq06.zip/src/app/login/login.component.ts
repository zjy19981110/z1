import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

function usernameValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match('')) {
    return { invalidusername: true };
  }
}
function passwordValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match(/^[0-9]+$/)) {
    return { invalidpassword: true };
  }
}
function pinValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match(/^[0-9]+$/)) {
    return { invalidpin: true };
  }
}
function phoneValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match(/^[0-9]+$/)) {
    return { invalidPhone: true };
  }
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  myForm: FormGroup;
  username: AbstractControl;
  password: AbstractControl;
  pin: AbstractControl;
  phone: AbstractControl;
  loginfalid: boolean;

  constructor(fb: FormBuilder, private httpclient: HttpClient) {
    this.myForm = fb.group({
      'username': ['', Validators.compose([Validators.required, usernameValidator])],
      'password': ['', Validators.compose([Validators.required, passwordValidator])],
      'pin': ['', Validators.compose([Validators.min(1000), Validators.max(9999), pinValidator])],
      'phone': ['', Validators.compose([Validators.minLength(11), Validators.maxLength(11), phoneValidator])]
    });

    this.username = this.myForm.controls['username'];
    this.password = this.myForm.controls['password'];
    this.pin = this.myForm.controls['pin'];
    this.phone = this.myForm.controls['phone'];
    this.loginfalid = false;
  }

  ngOnInit() {
  }
  onSubmit(value: string): void {
    console.log('you submitted value:', value);
    this.httpclient.post('http://127.0.0.1:8086/login', JSON.stringify(value)).subscribe(
      (resp: any) => {
        console.log(resp);
        if (resp.success) {
          alert("登录成功");
        }
        else {
          alert("登录失败");
        }
      }
    );
  }
}
